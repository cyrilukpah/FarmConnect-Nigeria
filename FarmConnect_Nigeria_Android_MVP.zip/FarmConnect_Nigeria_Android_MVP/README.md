# FarmConnect Nigeria Android MVP
Native Kotlin Android starter for the FarmConnect marketplace.

Included: home/search, sample listings, post listing form, WhatsApp contact.

Build in Android Studio with Gradle. This is an MVP; listings are in memory. Production requires authentication, database, image storage, moderation, secure payments and notifications.
