package com.farmconnect.nigeria

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

data class Listing(val title:String,val category:String,val price:String,val location:String,val seller:String,val phone:String,val emoji:String,val description:String)

class MainActivity: AppCompatActivity() {
 private val green=Color.rgb(23,107,58)
 private val listings=mutableListOf(
  Listing("Large white pig — 85 kg","Pigs & Piglets","₦250,000","Abakaliki","Chukwu Farm","08000000001","🐖","Healthy market-size pig. Buyer inspection welcome."),
  Listing("Piglets — 8 weeks","Pigs & Piglets","₦55,000 each","Enugu","Green Valley Farm","08000000002","🐷","Healthy weaned piglets. Quantity available."),
  Listing("Premium pig feed","Feeds","₦38,000 / bag","Aba","AgroFeed Depot","08000000003","🌾","Grower feed. Bulk orders accepted."),
  Listing("Veterinary farm visit","Veterinary Services","From ₦10,000","Owerri","Dr. FarmVet","08000000004","🩺","Livestock consultation and farm health checks."),
  Listing("Used feed mixer","Farm Equipment","₦450,000","Onitsha","Agro Machines","08000000005","🚜","Working feed mixer; inspection before purchase.")
 )
 override fun onCreate(state:Bundle?){super.onCreate(state);home()}
 private fun base():LinearLayout{val l=LinearLayout(this);l.orientation=LinearLayout.VERTICAL;l.setPadding(24,20,24,20);l.setBackgroundColor(Color.rgb(244,248,245));return l}
 private fun tv(s:String,n:Float=16f):TextView{val t=TextView(this);t.text=s;t.textSize=n;t.setTextColor(Color.rgb(23,32,24));t.setPadding(0,7,0,7);return t}
 private fun bt(s:String,f:()->Unit):Button{val b=Button(this);b.text=s;b.setOnClickListener{f()};return b}
 private fun home(){val r=base();val h=tv("🐷 FarmConnect Nigeria",27f);h.setTextColor(green);h.gravity=Gravity.CENTER;r.addView(h);r.addView(tv("Buy • Sell • Connect with farmers",14f));val q=EditText(this);q.hint="Search pigs, feed, vet, equipment...";r.addView(q);r.addView(bt("Search"){search(q.text.toString())});r.addView(bt("+ Post a Listing"){addListing()});val l=LinearLayout(this);l.orientation=LinearLayout.VERTICAL;listings.forEach{card(l,it)};val s=ScrollView(this);s.addView(l);r.addView(s,LinearLayout.LayoutParams(-1,0,1f));setContentView(r)}
 private fun search(q:String){val r=base();r.addView(tv("Search results",24f));r.addView(bt("← Home"){home()});val l=LinearLayout(this);l.orientation=LinearLayout.VERTICAL;listings.filter{("${it.title} ${it.category} ${it.location} ${it.seller}").contains(q,true)}.forEach{card(l,it)};if(l.childCount==0)l.addView(tv("No matching listings."));val s=ScrollView(this);s.addView(l);r.addView(s,LinearLayout.LayoutParams(-1,0,1f));setContentView(r)}
 private fun card(p:LinearLayout,x:Listing){val b=LinearLayout(this);b.orientation=LinearLayout.VERTICAL;b.setPadding(12,12,12,12);b.setBackgroundColor(Color.WHITE);b.addView(tv("${x.emoji}  ${x.title}",19f));b.addView(tv(x.price,18f));b.addView(tv("📍 ${x.location} • ${x.category}"));b.addView(tv("Seller: ${x.seller}"));b.addView(tv(x.description,14f));b.addView(bt("WhatsApp Seller"){var n=x.phone.filter{it.isDigit()};if(n.startsWith("0"))n="234"+n.drop(1);startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/$n?text="+Uri.encode("Hello, I saw your FarmConnect listing: ${x.title}"))))});p.addView(b,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,8,0,8)})}
 private fun addListing(){val r=base();r.addView(tv("Post a Farm Listing",24f));val a=EditText(this);a.hint="Listing title";r.addView(a);val c=EditText(this);c.hint="Category";r.addView(c);val pr=EditText(this);pr.hint="Price";r.addView(pr);val lo=EditText(this);lo.hint="Location";r.addView(lo);val se=EditText(this);se.hint="Seller/business name";r.addView(se);val ph=EditText(this);ph.hint="WhatsApp/phone";r.addView(ph);val d=EditText(this);d.hint="Description";r.addView(d);r.addView(bt("Publish Listing"){listings.add(0,Listing(a.text.toString(),c.text.toString(),pr.text.toString(),lo.text.toString(),se.text.toString(),ph.text.toString(),"🌱",d.text.toString()));home()});r.addView(bt("Cancel"){home()});setContentView(r)}
}
